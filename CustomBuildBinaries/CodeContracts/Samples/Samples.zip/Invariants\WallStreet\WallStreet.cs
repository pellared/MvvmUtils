﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WallStreet {
  public class WallStreetAccount : BasicBankAccount.BankAccount {

    private int slushFund;


    public override void Deposit(int amount) {
      if (100 < amount) {
        this.slushFund += amount;
        this.balance -= amount;
      } else {
        base.Deposit(amount);
      }
    }


  }
}
