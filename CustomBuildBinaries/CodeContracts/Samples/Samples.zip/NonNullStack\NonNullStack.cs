﻿using System.Diagnostics.Contracts;

namespace MyDataStructures
{
  public class NonNullStack<T>
  where T : class
  {
    [ContractInvariantMethod]
    void ObjectInvariant()
    {
      Contract.Invariant(arr != null);

      Contract.Invariant(nextFree >= 0);
      Contract.Invariant(nextFree <= arr.Length);

      Contract.Invariant(Contract.ForAll(0, nextFree, i => arr[i] != null));
    }

    protected T[] arr;
    private int nextFree;

    public NonNullStack(int len)
    {
      Contract.Requires(len >= 0);

      this.arr = new T[len];
      this.nextFree = 0;
    }

    public void Push(T x)
    {
      Contract.Requires(x != null);

      if (nextFree == arr.Length)
      {
        var newArr = new T[arr.Length * 2 + 1];
        for (int i = 0; i < nextFree; i++)
        {
          newArr[i] = arr[i];
        }

        arr = newArr;
      }

      this.arr[nextFree++] = x;
    }

    public T Pop()
    {
      Contract.Requires(!this.IsEmpty);
      Contract.Ensures(Contract.Result<T>() != null);

      return this.arr[--nextFree];
    }

    public bool IsEmpty
    {
      get { return this.nextFree == 0; }
    }

    public int Count
    {
      get
      {
        return this.nextFree;
      }
    }
  }
}
