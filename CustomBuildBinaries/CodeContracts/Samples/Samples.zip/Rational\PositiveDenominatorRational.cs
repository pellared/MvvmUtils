﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace CodeContracts.Samples
{
  public class PositiveDenominatorRational : Rational
  {
    public PositiveDenominatorRational(int n, int d) :
      base(n,d)
    {
      Contract.Requires(d != 0);
      Normalize();
    }

    void Normalize()
    {
      if (this.Denominator < 0)
      {
        this.Denominator = -this.Denominator;
        this.Numerator = -this.Numerator;
      }
    }

    public override void Divide(int divisor)
    {
      base.Divide(divisor);
    }

    [ContractInvariantMethod]
    private void PositiveDenominatorInvariant()
    {
      Contract.Invariant(this.Denominator > 0);
    }
  }
}
