﻿using System;
using System.Diagnostics.Contracts;

namespace ChunkerTest
{
  /// <summary>
  /// A chunker object holds a string and a chunkSize. It breaks the string into equal sized 
  /// substrings of chunkSize. Each substring is provided by repeated calls to NextChunk.
  /// </summary>
  class Chunker
  {
    /// <summary>
    /// the string from which we return chunks
    /// </summary>
    readonly string stringData;

    /// <summary>
    /// the size of each chunk
    /// </summary>
    readonly int chunkSize;

    /// <summary>
    /// The number of characters in stringData we already returned in chunks
    /// </summary>
    int returnedCount;

    [ContractInvariantMethod]
    private void ObjectInvariant()
    {
      Contract.Invariant(chunkSize > 0);
      Contract.Invariant(returnedCount >= 0);
      Contract.Invariant(stringData != null);
      Contract.Invariant(returnedCount <= stringData.Length);
    }

    public string NextChunk()
    {
      string s;
      if (returnedCount <= stringData.Length - chunkSize)
      {
        s = stringData.Substring(returnedCount, chunkSize);
      }
      else
      {
        s = stringData.Substring(returnedCount);
      }
      returnedCount += s.Length;
      return s;
    }

    public Chunker(string source, int chunkSize)
    {
      Contract.Requires(chunkSize>0);
      Contract.Requires(source != null);

      this.stringData = source;
      this.chunkSize = chunkSize;
      returnedCount = 0;
    }
  }



}
