using System;
using System.Diagnostics.Contracts;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeContracts.Samples
{
  [ContractVerification(false)]
  public class NormalizedRational : Rational
  {
    public NormalizedRational(int n, int d)
      : base(n, d)
    {
      this.Normalize();
    }
    [Pure]
    private static int GCD(int x, int y)
    {
      // find greatest common divisor of x and y
      int ans;
      int z;
      if (x < y)
        ans = NormalizedRational.GCD(y, x);
      else if (x % y == 0)
        ans = y;
      else
      {
        z = x % y;
        ans = NormalizedRational.GCD(y, z);
      }
      return ans;
    }
    private void Normalize()
    {
      if (this.Numerator == 0)
      {
        this.Denominator = 1;
      }
      else
      {
        var g = NormalizedRational.GCD(this.Numerator, this.Denominator);
        this.Numerator = this.Numerator / g;
        this.Denominator = this.Denominator / g;
      }
    }

    public override void Divide(int divisor)
    {
      base.Divide(divisor);
      Normalize();
    }

    [ContractInvariantMethod]
    private void NormalizedInvariant()
    {
      Contract.Invariant(NormalizedRational.GCD(this.Numerator, this.Denominator) == 1);
    }

  }

}
 
