﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics.Contracts;

namespace Demo
{
  class Program
  {


    static void Main(string[] args)
    {
      if (args.Length < 1) return;
      var argString = args[0];
      Contract.Assume(argString != null);

      int daysSince1980 = Int32.Parse(args[0]);

      int dayInYear;
      int year = ZuneDate.YearSince1980(daysSince1980, out dayInYear);

      string[] days;
      days = new string[366];

      days[dayInYear] = "used";

    }
  }
}
