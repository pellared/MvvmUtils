﻿using System;
using System.Diagnostics.Contracts;

namespace ChunkerTest
{
  /// <summary>
  /// A chunker object holds a string and a chunkSize. It breaks the string into equal sized 
  /// substrings of chunkSize. Each substring is provided by repeated calls to NextChunk.
  /// </summary>
  class Chunker
  {
    /// <summary>
    /// the string from which we return chunks
    /// </summary>
    readonly string stringData;

    /// <summary>
    /// the size of each chunk
    /// </summary>
    readonly int chunkSize;

    /// <summary>
    /// The number of characters in stringData we already returned in chunks
    /// </summary>
    int returnedCount;

    public string NextChunk()
    {
      string s;
      s = stringData.Substring(returnedCount, chunkSize);
      returnedCount += s.Length;
      return s;
    }

    public Chunker(string source, int chunkSize)
    {
      this.stringData = source;
      this.chunkSize = chunkSize;
      returnedCount = 0;
    }
  }



}
