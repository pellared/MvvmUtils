﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Invariants {
  class Client {
    static void Main(string[] args) {
      BasicBankAccount.BankAccount b = new BasicBankAccount.BankAccount();
      b.Deposit(-5);
      WallStreet.WallStreetAccount w = new WallStreet.WallStreetAccount();
      w.Deposit(150);
    }
  }
}
